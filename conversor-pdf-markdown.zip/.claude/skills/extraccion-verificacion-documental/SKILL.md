---
name: extraccion-verificacion-documental
description: Extrae texto de PDF e imágenes, aplica OCR local a páginas escaneadas y verifica identificadores, fechas e importes con referencias a página. Usa al preparar documentación de subastas o al contrastar transcripciones.
---

# Extracción y verificación documental

1. Confirma los originales y busca primero un extractor ya existente en el expediente. No cambies las fuentes.
2. Ejecuta `scripts/pdf_to_markdown.py` con el Python de `.venv`; extrae texto nativo y aplica RapidOCR a las páginas sin texto. Para inicializar el entorno, consulta [references/entorno-ocr.md](references/entorno-ocr.md).
3. Usa [assets/transcripcion-template.md](assets/transcripcion-template.md) como referencia de estructura. El script escribe un derivado `.extracted.md`, no sobrescribe por defecto y marca página y método.
4. Revisa cifras e identificadores materiales contra el PDF o imagen original. OCR es una transcripción, no una verificación.
5. Si se pidió guardar resultados, conserva los nombres de origen, páginas y fecha; añade el nuevo documento al README del expediente.
6. Devuelve campos comprobados, página, documento, método (texto nativo/OCR), discrepancias y limitaciones.

## Herramientas

Los permisos los aporta el agente activo. Para convertir, requiere ejecución local con Python 3.10+, PyMuPDF, NumPy, Pillow y RapidOCR dentro del entorno del repo. Este skill incluye los scripts de preparación y conversión.
